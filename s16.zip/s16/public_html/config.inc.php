<?php

$config = [
    'db_host'     => 'localhost',
    'db_name'     => 's16',
    'db_user'     => 's16',
    'db_password' => 'nojf5jy7'
];

?>		