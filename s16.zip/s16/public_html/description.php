<section class="description">
	<div class="container">
		<div class="add-heading">
			<h2>Krótka instrukcja obsługi</h2>
        </div>
        <h4>Strona główna</h4>
        <p> Tutaj wyświetalają się wszytskie obrazki z bazy danych. Miniaturki są dostosowane do założonego rozmiaru 300x200px, zdjęcia są automatycznie kadrowane. Naturalnie, możesz też wyświetlić zdjęcia z wybranej kategorii wybierając i zatwierdzając takową w prawym górym rogu strony. Po kliknięciu w miniaturkę zostajesz przeniesiony do trybu edycji. </p>
        <h4>Kategorie</h4>
        <p> Tutaj możesz dodać lub usunąć wybraną kategorię. Przyjmowane są wyrażenia dłuższe niż 1 znak, dozwolone są spacje. </p>
        <h4>Dodaj zdjęcie</h4>
        <p> Tutaj możesz dodać zdjęcie uploadując je z dysku na nasz serwer. Dozwolona opcja drag&drop.</p>
   
    </div>
</section>  